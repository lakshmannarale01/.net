﻿namespace NumberExercise.Interfaces
{
    public interface INumberService
    {
        List<int> FindSquare(int[] numbers);
    }
}
