﻿namespace CardValidation.Models
{
    public class CardResult : Card
    {
        public bool IsValid { get; set; }
    }
}
