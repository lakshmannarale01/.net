﻿namespace XYZHotels.Models.DTOs
{
    public class HotelLocationDTO
    {
        public int Id { get; set; }

        public string Location { get; set; }
    }
}
