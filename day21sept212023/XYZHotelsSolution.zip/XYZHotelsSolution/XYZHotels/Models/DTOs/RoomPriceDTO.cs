﻿namespace XYZHotels.Models.DTOs
{
    public class RoomPriceDTO
    {
        public int RoomNo { get; set; }
        public double price { get; set; }
    }
}
