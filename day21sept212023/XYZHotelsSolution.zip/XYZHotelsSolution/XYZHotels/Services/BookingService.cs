﻿using System.Numerics;
using XYZHotels.ExceptionHandle;
using XYZHotels.Interfaces;
using XYZHotels.Models;
using XYZHotels.Models.DTOs;

namespace XYZHotels.Services
{
    public class BookingService : IBookingService
    {
        private readonly IRepository<int, Booking> _repo;
        private readonly IRepository<int, Room> _repoRoom;

        public BookingService(IRepository <int , Booking> repository , IRepository<int , Room> repository1)
        {
            _repo=repository;
            _repoRoom = repository1;
        }
     

        public Booking AddBooking(Booking booking)
        {
            bool book = CheckAvailability(booking);
            if (book == true)
            {
                _repo.Add(booking);
                return booking;
            }
            else
            {
                throw new RoomNotAvailableExceptions();
            }
        }
        //------------------------------------------------------------------one new method---------------------------------------------------
        //public Booking AddBooking(Booking booking)
        //{
        //    BookingCheckAvalibilityDTO bca= new BookingCheckAvalibilityDTO
        //    {
        //        BookingDateTime = booking.BookingDateTime,
        //            RoomNo = booking.RoomNo
        //    };
        //    if(CheckAvailability(bca) == true) 
        //    {
        //        var book = _repo.Add(booking);
        //        return book;
        //    }
        //    throw new RoomNotAvailableExceptions();
        //}
        //--------------------------------------------------------------------------------------------------------------------------------------


        public Booking CancelBooking(int id)
        {
            var mybook = _repo.Get(id);
            if(mybook == null)
            {
                throw new NoEntriesAvailable("Rooms");
            }
            mybook =_repo.Delete(mybook.BookingId);
            return mybook;
        }
   
      public bool CheckAvailability(Booking booking)
        { if (booking != null) {
                Room details = _repoRoom.Get(booking.RoomNo);
                if(details != null)
                {
                    var book = _repo.GetAll();
                    var existingBooking =  book.Where(b=>b.RoomNo == booking.RoomNo 
                    && b.BookingDateTime==booking.BookingDateTime).ToList();
                    if(existingBooking != null)
                    {
                        return false;
                    }
                    else
                    {
                        return true;
                    }
                }
                else
                {
                    throw new RoomNotAvailableExceptions();
                }
            }
            else
            {
                throw new RoomNotAvailableExceptions();
            }

        //---------------------------------------------------one more method for checkavailability-------------------------------------------
            //try
            //{
            //    var book = _repo.GetAll();
            //    var checkBooking = book.FirstOrDefault(x=>x.RoomNo== booking.RoomNo && x.BookingDateTime==booking.BookingDateTime);
            //    return checkBooking == null;
            //}
            //catch (RoomNotAvailableExceptions e )
            //{

            //    return true;
            //}
            //catch(NoEntriesAvailable e)
            //{
            //    return true;
            //}
            //-----------------------------------------------------------------------------------------------------------------------------------
        }

    

        public IList<Booking> GetAll()
        {
          return _repo.GetAll().ToList();
        }
    }
}
