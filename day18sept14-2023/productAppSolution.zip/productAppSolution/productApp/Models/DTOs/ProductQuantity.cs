﻿namespace productApp.Models.DTOs
{
    public class ProductQuantity
    {
        public int Id { get; set; }
        public int Quantity { get; set; }
    }
}

