﻿namespace productApp.Models.DTOs
{
    public class ProductPriceDTO
    {
        public int Id { get; set; }
        public double Price { get; set; }
    }
}

