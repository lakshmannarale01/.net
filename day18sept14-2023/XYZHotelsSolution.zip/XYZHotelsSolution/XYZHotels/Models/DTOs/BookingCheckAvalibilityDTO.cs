﻿namespace XYZHotels.Models.DTOs
{
    public class BookingCheckAvalibilityDTO
    {
        public int RoomNo { get; set; }

        public DateTime BookingDateTime { get; set; }
    }
}
