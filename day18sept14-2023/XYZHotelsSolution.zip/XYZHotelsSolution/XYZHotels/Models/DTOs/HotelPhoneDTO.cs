﻿namespace XYZHotels.Models.DTOs
{
    public class HotelPhoneDTO
    {
        public int Id { get; set; }
        public string Phone { get; set; }
    }
}
